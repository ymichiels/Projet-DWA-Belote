create table joueur
(
    joueur_id   int         not null
        primary key,
    nb_victoire int         null,
    score_moyen float       null,
    nb_partie   int         null,
    pseudo      varchar(20) not null,
    DTYPE       varchar(15) not null,
    sexe        char        null
)
    engine = InnoDB
    charset = utf8;

create table humain
(
    joueur_id    int         not null
        primary key,
    mot_de_passe char(32)    not null,
    age          smallint    null,
    ville        varchar(20) null,
    constraint humain_ibfk_1
        foreign key (joueur_id) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;

create table partie
(
    partie_id int      not null
        primary key,
    eq_1a     int      null,
    eq_1b     int      null,
    score_eq1 smallint null,
    eq_2a     int      null,
    eq_2b     int(1)   null,
    score_eq2 smallint null,
    duree     time     null,
    constraint partie_ibfk_1
        foreign key (eq_1a) references joueur (joueur_id),
    constraint partie_ibfk_2
        foreign key (eq_1b) references joueur (joueur_id),
    constraint partie_ibfk_3
        foreign key (eq_2a) references joueur (joueur_id),
    constraint partie_ibfk_4
        foreign key (eq_2b) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;

create table manche
(
    partie_id      int         not null,
    manche_nb      tinyint     not null,
    couleur_atout  char(8)     null,
    joueur_prenant int         null,
    atout_initial  varchar(13) null,
    atout_final    varchar(13) null,
    point_manche   smallint    null,
    primary key (partie_id, manche_nb),
    constraint manche_ibfk_1
        foreign key (partie_id) references partie (partie_id),
    constraint manche_ibfk_2
        foreign key (joueur_prenant) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;

create table main
(
    partie_id int         not null,
    manche_nb tinyint     not null,
    joueur_id int         not null,
    carte_1   varchar(13) null,
    carte_2   varchar(13) null,
    carte_3   varchar(13) null,
    carte_4   varchar(13) null,
    carte_5   varchar(13) null,
    carte_6   varchar(13) null,
    carte_7   varchar(13) null,
    carte_8   varchar(13) null,
    primary key (partie_id, manche_nb, joueur_id),
    constraint main_ibfk_1
        foreign key (partie_id, manche_nb) references manche (partie_id, manche_nb),
    constraint main_ibfk_2
        foreign key (joueur_id) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;

create index joueur_id
    on main (joueur_id);

create index joueur_prenant
    on manche (joueur_prenant);

create index eq_1a
    on partie (eq_1a);

create index eq_1b
    on partie (eq_1b);

create index eq_2a
    on partie (eq_2a);

create index eq_2b
    on partie (eq_2b);

create table plis
(
    partie_id    int             not null,
    manche_nb    tinyint         not null,
    plis_nb      tinyint         not null,
    joueur_debut int             null,
    carte_1      varchar(13)     null,
    carte_2      varchar(13)     null,
    carte_3      varchar(13)     null,
    carte_4      varchar(13)     null,
    note         char default '' null,
    primary key (partie_id, manche_nb, plis_nb),
    constraint plis_ibfk_1
        foreign key (partie_id, manche_nb) references manche (partie_id, manche_nb),
    constraint plis_ibfk_2
        foreign key (joueur_debut) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;

create index joueur_debut
    on plis (joueur_debut);

create table robot
(
    joueur_id int         not null
        primary key,
    programme varchar(20) not null,
    constraint robot_ibfk_1
        foreign key (joueur_id) references joueur (joueur_id)
)
    engine = InnoDB
    charset = utf8;
